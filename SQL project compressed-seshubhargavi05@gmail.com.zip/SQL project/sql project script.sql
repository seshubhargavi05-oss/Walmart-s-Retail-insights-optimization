create database walmart;
select * from walmartsales;
----TASK 1  Identifying the Top Branch by Sales Growth Rate ----
           SELECT *
FROM (
    SELECT 
        branch,
        `year_month`,
        current_mon_sales,
        LAG(current_mon_sales) OVER (PARTITION BY branch ORDER BY `year_month`) AS previous_mon_sales,
        current_mon_sales - LAG(current_mon_sales) OVER (PARTITION BY branch ORDER BY `year_month`) AS growth
    FROM (
        SELECT 
            branch, 
            DATE_FORMAT(`date`, '%Y-%m') AS `year_month`, 
            ROUND(SUM(total),0) AS current_mon_sales
        FROM walmartsales
        GROUP BY branch, `year_month`
    ) AS monthly_totals
) AS growth_calc
WHERE growth IS NOT NULL
ORDER BY growth DESC
LIMIT 1;
-----task 2 finding profitable product line for each branch ------
SELECT
    branch,
    `product line`,
    profit_margin
FROM (
    SELECT  
        branch,
        `product line`, 
        ROUND(SUM(`gross income`),0) AS total_gross_income,
        ROUND(SUM(cogs),0) AS total_cogs,
        ROUND(SUM(`gross income`),0) - ROUND(SUM(cogs),0) AS profit_margin,
        DENSE_RANK() OVER (
            PARTITION BY branch 
            ORDER BY (ROUND(SUM(`gross income`),0) - ROUND(SUM(cogs),0)) DESC
        ) AS profitable_product
    FROM walmartsales
    GROUP BY branch, `product line`
) AS ranked
WHERE profitable_product = 1;
-----task 3 Analyzing Customer Segmentation Based on Spending-----
select `Customer ID` , round(sum(total),0) as total_spent
from walmartsales
group by `Customer ID`
order by `Customer ID`;
select 
min(total_spent),max(total_spent),round(avg(total_spent),0) from
(select `Customer ID` , round(sum(total),0) as total_spent
from walmartsales
group by `Customer ID`
order by `Customer ID`) as spending;
select `customer ID`,total_spent,
case
when total_spent>21531 then 'high'
when total_spent between 17657 and 21531 then 'medium'
else 'low'
end as spending_tier
from (select `Customer ID` , round(sum(total),0) as total_spent
from walmartsales group by `customer id`) as spending
group by `customer id`
order by `customer id`;
-----task 4  Detecting Anomalies in Sales Transactions----
select monthname(date), `product line` ,round(avg(total),0) as average_total
from walmartsales
group by `product line`,monthname(date)
order by avg(total) , monthname(date);
SELECT
  `invoice id`,
  `product line`,
  ROUND(AVG(total) OVER (PARTITION BY `product line`, YEAR(`date`), MONTH(`date`)), 0) AS average_total,
  total,
  CASE
    WHEN total > 1.5 * ROUND(AVG(total) OVER (PARTITION BY `product line`, YEAR(`date`), MONTH(`date`)), 0) THEN 'High Anomaly'
    WHEN total < 0.5 * ROUND(AVG(total) OVER (PARTITION BY `product line`, YEAR(`date`), MONTH(`date`)), 0) THEN 'Low Anomaly'
    ELSE 'Normal'
  END AS anomaly
FROM walmartsales;
----task 5  Most Popular Payment Method by City-----
with payment_method as (
SELECT city, payment, COUNT(`Invoice ID`) AS count_payment_method
FROM walmartsales
GROUP BY city, payment),
ranked_payments as 
(select city,payment,count_payment_method,
row_number() over(partition by city order by count_payment_method desc) as rn
from payment_method)
select city,payment,count_payment_method
from ranked_payments
where rn = 1;
----task 6  Monthly Sales Distribution by Gender -----
select gender,monthname(`date`) as `month`,count(*) as no_sale_transaction ,round(sum(total),0) as total_sales
from walmartsales
group by gender,`month`
order by `month`,gender;
----task 7 Best Product Line by Customer Type-----
with product_sales as(
select `product line`,`customer type`,round(sum(total),0) as total_sales,
rank() over(partition by `customer type` order by round(sum(total),0) desc) as sales_rank
from walmartsales
group by `product line`,`customer type`)
select `product line`,`customer type`,total_sales
from product_sales
where sales_rank = 1;
-----task 8 Identifying Repeat Customers ----
select a.customer id,count(*) as repeat_purchases
from walmartsales as a
join walmartsales as b
on a.`customer id`= b.`customer id`
and a.`date`< b.`date`
and datediff(b.`date`, a.`date`) <= 10
group by a.`customer id`
order by repeat_purchases desc;
SELECT 
    a.`customer id`,
    a.`date` AS first_purchase_date,
    b.`date` AS repeat_purchase_date,
    DATEDIFF(b.`date`, a.`date`) AS days_between
FROM
    walmartsales a
JOIN
    walmartsales b
    ON a.`customer id` = b.`customer id`
    AND a.`date` < b.`date`
    AND DATEDIFF(b.`date`, a.`date`) <= 10
ORDER BY
    a.`customer id`, a.`date`;
-----task 9  Finding Top 5 Customers by Sales Volume -----
select `customer id`,round(sum(total),0) as total_revenue
from walmartsales
group by `customer id`
order by round(sum(total),0) desc
limit 5;
-----task 10 Analyzing Sales Trends by Day of the Week-----
select dayname(`date`) as `day`,round(sum(total),0) as total_sales
from walmartsales
group by dayname(`date`)
order by round(sum(total),0) desc;